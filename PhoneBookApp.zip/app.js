var express = require("express");
var app = express();
var bodyParser = require("body-parser");
var mongoose = require("mongoose");
var methodOverride = require("method-override");

mongoose.connect("mongodb://localhost/phonebookApp");
app.use(bodyParser.urlencoded({extended: true}));
app.set("view engine", "ejs");
app.use(express.static(__dirname + "/public"));
app.use(methodOverride("_method"));


//SHCEMA SETUP
var phonebookSchema = new mongoose.Schema({
    firstName: String,
    lastName: String,
    phone: Number
});

var Phonebook = mongoose.model("Phonebook", phonebookSchema);

// Phonebook.create(
//     {
//         firstName: "Nenad",
//         lastName: "Radisavljevic",
//         phone: 0641638262
      
//     }, function(err, phonebook){
//           if(err){
//             console.log(err);
//           } else {
//             console.log("Added new Contact "+ phonebook);
            
//           }
//     });

// INDEX - show all contacts
app.get("/phonebook", function(req, res){
  //get all contacts from DB
  Phonebook.find({}, function(err, phonebook){
    if(err){
            console.log(err);
          } else {
        res.render("phonebook", {phonebook:phonebook}); 
          }
          });
});


// CREATE - add new contact to DB
app.post("/phonebook", function(req, res) {
   //get data from form and add to phonebook array
   var firstName = req.body.firstName;
   var lastName = req.body.lastName;
   var phone = req.body.phone;
   var newContact = {firstName: firstName, lastName: lastName, phone: phone}
   //Create a new contact and save to DB
   Phonebook.create(newContact, function(err, newCont){
     if(err){
            console.log(err);
          } else {
             // redirect back to phonebook page
             res.redirect("/phonebook");
          }
   });
});


//NEW - show form to create new contact
app.get("/phonebook/new", function(req, res){
   res.render("addContact");
});

//DESTROY 
app.delete("/phonebook/:id", function(req, res){
    Phonebook.findByIdAndRemove(req.params.id, function(err){
      if(err){
        res.redirect("/phonebook");
      } else {
                res.redirect("/phonebook");

      }
    });
});


app.listen(3000, function(){
  console.log("Server 3000 online");
});